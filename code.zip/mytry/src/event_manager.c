#include<header.h>
#include<samplehead.h>
void reg_event(int num,int event,fptr fp)
{
	struct event_register *temp,*t;
	temp=(struct event_register *)malloc(sizeof(struct event_register));
	t=head;
	if(t==NULL)
	{
		temp->module_id=num;
		temp->event_bitmap=event;
		temp->fp=fp;
		temp->next=NULL;
		head=temp;
	}
	else
	{
		while(t->next!=NULL)
		{
			t=t->next;
			temp->module_id=num;
			temp->event_bitmap=event;
			temp->fp=fp;
			t->next=temp;
			temp->next=NULL;
		}
	}

}

void event(int event_n)
{
	struct event_register *temp=head;
	int t=0;
	while(temp!=NULL)
	{
		t=((temp->event_bitmap >> (event_n -1)) & 1);
		if(t!=0)
		{
			temp->fp();
		}
		temp=temp->next;
	}
}
