#include<stdio.h>
#include<stdlib.h>
#include<header.h>
void module1()
{
	printf("%s\n",__func__);
}

void module2()
{
	printf("%s\n",__func__);
}

void module3()
{
	printf("%s\n",__func__);
}

void module4()
{
	printf("%s\n",__func__);
}
void module5()
{
	printf("%s\n",__func__);
}

void init(int num)
{
	int event=0,eve;
	fptr fp;
	for(;;)
	{
		printf("Events number\n");
		scanf("%d",&eve);
		if(eve>=1 && eve<=n)
		{
			event=bitmapping(event,eve);
		}
		else
		{
			break;
		}
	}
	if(num==1)
	{
		fp=module1;
	}
	else if(num==2)
	{
		fp=module2;
	}
	else if(num==3)
	{
		fp=module3;
	}
	else if(num==4)
	{
		fp=module4;
	}
	else
	{
		fp=module5;
	}
	reg_event(num,event,fp);
	
}
