#include<stdio.h>
#include<stdlib.h>
#include<header.h>
int main()
{
	int event_number,number_of_events,i;
	printf("Enter the number of Events\n");
	scanf("%d",&number_of_events);
	for(i=1;i<=5;i++)
	{
		printf("Events entering for module %d\n",i);
		init(i);
	}
	printf("**Event interested in******\n");
	scanf("%d",&event_number);
	event(event_number);
}
