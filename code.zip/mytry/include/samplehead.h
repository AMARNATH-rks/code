struct event_register
{
        int module_id;
        int event_bitmap;
        fptr fp;
        struct event_register *next;
}*head=NULL;

